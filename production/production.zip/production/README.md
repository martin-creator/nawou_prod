composer install --no-dev

php artisan key:generate

npm run build

php artisan migrate --force

php artisan storage:link

php artisan serve
